/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author denze
 */
public class Jugadores {
     
    private int id;
    private String nom;
    private String ape;
    private String posicion;
    private String valor;
    
    public String getPosicion() {
        return posicion;
    }

    
    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getId() {
        return id;
    }

    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
    
}
