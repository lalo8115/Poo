/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora1;
import java.util.Scanner;

/**
 *
 * @author denze
 */
public class Calculadora1 {
static Scanner nums = new Scanner (System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Operaciones op = new Operaciones();
        OpAvan av = new OpAvan();
        
        System.out.print("Ingresa el primer valor: ");
        double n = nums.nextDouble();
        System.out.print("Ingresa el segundo valor: ");
        double x = nums.nextDouble();
        
        double resultado;
        System.out.println("Operaciones basicas: Se van a calcular las operaciones basicas a los valores que ingreses.");
   
        System.out.print("Resultados operaciones basicas\n");
        resultado=op.suma(n, x);
        System.out.println("La suma de " + n + "+" + x + "=" + resultado);
        resultado=op.resta(n, x);
        System.out.println("La resta de " + n + "-" + x + "=" + resultado); 
        resultado=op.division(n, x);
        System.out.println("La division de " + n + "/" + x + "=" + resultado);
        resultado=op.multi(n, x);
        System.out.println("La multiplicacion de " + n + "*" + x + "=" + resultado);
    
        System.out.println("Operaciones avanzadas: Se va a calcular el triple de un numero");
        System.out.println("Ingresa el numero");
        x = nums.nextDouble();
        
        double trip;
        trip = av.triple(x);
        System.out.println("El triple del numero"+trip);
    
    }
    
}
