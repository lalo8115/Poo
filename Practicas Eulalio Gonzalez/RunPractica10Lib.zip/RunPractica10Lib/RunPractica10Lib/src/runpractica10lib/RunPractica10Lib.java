/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package runpractica10lib;

import Lib.Calculadora;
import java.util.Scanner;
/**
 *
 * @author eulalio
 */
public class RunPractica10Lib {

    static Scanner num = new Scanner(System.in);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        double a,b;
        
        Calculadora casio = new Calculadora();
        System.out.println("Ingresa los numeros con los que trabajaremos");
        a = num.nextDouble();
        b = num.nextDouble();
        System.out.println("La suma es: ");
        System.out.println(casio.suma(a, b));
        System.out.println("La resta es: ");
        System.out.println(casio.resta(a, b));
        System.out.println("La division es: ");
        System.out.println(casio.division(a, b));
        System.out.println("La multiplicacion es: ");
        System.out.println(casio.multiplicacion(a, b));
    }
    
}
