/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package runpractica8;

import java.io.File;

/**
 *
 * @author eulalio
 */
public class RunPractica8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        WriteAFile fl = new WriteAFile( "C:\\Users\\denze\\OneDrive\\Escritorio\\file.txt");
        
    }
    
}
