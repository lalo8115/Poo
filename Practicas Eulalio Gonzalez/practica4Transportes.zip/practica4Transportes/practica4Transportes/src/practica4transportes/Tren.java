/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4transportes;

import vehiculos.Vehiculo;
/**
 *
 * @author eulal
 */
public class Tren extends Vehiculo{
     public Tren(){
        
    }
    public Tren(int carbon){
        this.encenderTren(carbon);
        this.avanzaTren(carbon);
    }
    
    public Tren(double energuia){
        this.encenderTren(energuia);
        this.avanzaTren(energuia);
    }
    
    private void encenderTren(int carbon){
        if(carbon > 1){
            System.out.println("Avion encendido. Diesel suficiente.");
        }else{
            System.out.println("No hay suficiente Diesel.");
        }
    }
    
    private void avanzaTren(int carbon){
        if(carbon > 1 && carbon < 20){
            System.out.println("Queda poca carga");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
    
    private void encenderTren(double energuia){
        if(energuia > 1){
            System.out.println("Avion encendido. Energuia suficiente.");
        }else{
            System.out.println("No hay suficiente Energuia.");
        }
    }
    
    private void avanzaTren(double energuia){
        if(energuia > 1 && energuia < 20){
            System.out.println("Queda poca carga");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
}
