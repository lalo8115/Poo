/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4transportes;

import vehiculos.Vehiculo;

public class Automovil extends Vehiculo{
    
    public Automovil (){
    
    }
    
        
    public Automovil(int gas){
        this.encenderAutomovil(gas);
        this.avanzaAutomovil(gas);
    }
    
    public Automovil(double energuia){
        this.encenderAutomovil(energuia);
        this.avanzaAutomovil(energuia);
    }
    
    private void encenderAutomovil(int gas){
        if(gas > 1){
            System.out.println("Automovil encendido. Gasolina suficiente.");
        }else{
            System.out.println("No hay suficiente gasolina.");
        }
    }
    
    private void avanzaAutomovil(int gas){
        if(gas > 1 && gas < 10){
            System.out.println("Queda poco gas");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
    
    private void encenderAutomovil(double energuia){
        if(energuia > 1){
            System.out.println("Automovil encendido. Bateria Suficiente.");
        }else{
            System.out.println("No tiene suficiente carga.");
        }
    }
    
    private void avanzaAutomovil(double energuia){
        if(energuia > 1 && energuia < 20){
            System.out.println("Queda poca carga");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
}
