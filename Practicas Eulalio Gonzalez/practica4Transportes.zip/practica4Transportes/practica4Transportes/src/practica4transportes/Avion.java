/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4transportes;
import vehiculos.Vehiculo;
/**
 *
 * @author eulal
 */
public class Avion extends Vehiculo{
    
    public Avion(){
        
    }
    public Avion(int diesel){
        this.encenderAvion(diesel);
        this.avanzaAvion(diesel);
    }
    
    public Avion(double energuia){
        this.encenderAvion(energuia);
        this.avanzaAvion(energuia);
    }
    
    private void encenderAvion(int diesel){
        if(diesel > 1){
            System.out.println("Avion encendido. Diesel suficiente.");
        }else{
            System.out.println("No hay suficiente Diesel.");
        }
    }
    
    private void avanzaAvion(int diesel){
        if(diesel > 1 && diesel < 20){
            System.out.println("Queda poca carga");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
    
    private void encenderAvion(double energuia){
        if(energuia > 1){
            System.out.println("Avion encendido. Energuia suficiente.");
        }else{
            System.out.println("No hay suficiente Energuia.");
        }
    }
    
    private void avanzaAvion(double energuia){
        if(energuia > 1 && energuia < 20){
            System.out.println("Queda poca carga");
        }else{
            System.out.println("Puede avanzar.");
        }
    }
}
