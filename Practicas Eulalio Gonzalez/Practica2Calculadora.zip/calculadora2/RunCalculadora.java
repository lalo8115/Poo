/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora2;

import java.util.Scanner;

/**
 *
 * @author FCFM
 */
public class RunCalculadora {
    static Scanner nums = new Scanner (System.in);

     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
// TODO code application logic here
        Calculadora casio = new Calculadora();
        CalculadoraCientifica casioC= new CalculadoraCientifica();
        
        System.out.println("Se van a calcular operaciones con los valores que ingreses.");
        System.out.print("Ingresa el primer valor");
        double n = nums.nextDouble();
        System.out.print("Ingresa el segundo valor");
        double x = nums.nextDouble();
        
        System.out.println("Ingresa el numero al que le quieres sacar la raiz");
        double r = nums.nextDouble();
        System.out.println("Ingresa el numero al que le quieres sacar su cuadrado");
        double c = nums.nextDouble();
        
        System.out.print("Calculadora\n");
        System.out.println("La suma de " + n + "+" + x + "=" + casio.suma(n,x));
        System.out.println("La resta de " + n + "-" + x + "=" + casio.resta(n,x)); 
        System.out.println("La division de " + n + "/" + x + "=" + casio.multi(n, x));
        System.out.println("La multiplicacion de " + n + "*" + x + "=" + casio.div(n, x));
        
        System.out.print("\nCalculadora Cientifica\n");
        System.out.println("La suma de " + n + "+" + x + "=" + casio.suma(n,x));
        System.out.println("La resta de " + n + "-" + x + "=" + casio.resta(n,x)); 
        System.out.println("La division de " + n + "/" + x + "=" + casio.multi(n, x));
        System.out.println("La multiplicacion de " + n + "*" + x + "=" + casio.div(n, x));
        System.out.println("La raiz de " + r + " es = " + casioC.raiz(r));
        System.out.println("El cuadrado de " + c + " es = " + casioC.cuadrado(c));
        
    }
    
}
