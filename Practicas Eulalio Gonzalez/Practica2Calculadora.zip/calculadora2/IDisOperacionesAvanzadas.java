/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package calculadora2;

/**
 *
 * @author FCFM
 */
public interface IDisOperacionesAvanzadas {
    
    public double raiz(double a);
    
    public double cuadrado(double a);
    
}
