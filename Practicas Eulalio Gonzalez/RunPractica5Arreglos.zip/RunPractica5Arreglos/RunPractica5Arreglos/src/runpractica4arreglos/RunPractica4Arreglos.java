/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package runpractica4arreglos;

import java.util.Scanner;


/**
 *
 * @author eulalio
 */
public class RunPractica4Arreglos {
    
    static Scanner tipo = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil[] arreglo = new Automovil[1];
        double gas=0;
        int i=0;
        String nom;
        for(i=0;i<arreglo.length;i++){
            arreglo[i] = new Automovil();
            System.out.print("Ingresa el color del auto " + i+1);
            nom = tipo.next();
            arreglo[i].setColor(nom);
            System.out.print("Ingresa la marca del auto " + i+1);
            nom = tipo.next();
            arreglo[i].setMarca(nom);
            System.out.print("Ingresa el modelo del auto " + i+1);
            nom = tipo.next();
            arreglo[i].setModelo(nom);
            System.out.print("Ingresa el precio del auto " + i+1);
            gas = tipo.nextDouble();
            arreglo[i].setPrecio(gas);
            System.out.print("Ingresa la gasolina del auto " + i+1);
            gas = tipo.nextDouble();
            arreglo[i].setGas(gas);
        }
        i=0;
        for(Automovil auto: arreglo){
            i=i+1;
            System.out.println("Datos del auto " + i);
            System.out.println(auto.getMarca());
            System.out.println(auto.getColor());
            System.out.println(auto.getPrecio());
            System.out.println(auto.getModelo());
            System.out.println(auto.getGas());
            System.out.println(auto.encender(gas));
            System.out.println(auto.apagar());
        }
        
    }
    
}
