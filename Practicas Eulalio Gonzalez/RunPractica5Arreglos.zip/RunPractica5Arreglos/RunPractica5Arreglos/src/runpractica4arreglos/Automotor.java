/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica4arreglos;

/**
 *
 * @author eulalio
 */
public class Automotor {

    /**
     * @return the gas
     */
    public double getGas() {
        return gas;
    }

    /**
     * @param gas the gas to set
     */
    public void setGas(double gas) {
        this.gas = gas;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    private String modelo;
    private String marca;
    private double gas;
    
    public String encender(double gas){
        if(gas>=1)
            return "Auto encendido";
        else
            return "No hay suficiente combustible";
    }
    
    public String apagar(){
        return "Auto apagado";
    }
}
