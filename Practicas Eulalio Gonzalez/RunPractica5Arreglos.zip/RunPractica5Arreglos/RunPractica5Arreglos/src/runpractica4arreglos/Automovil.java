/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica4arreglos;

/**
 *
 * @author eulalio
 */
public class Automovil extends Automotor{

    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
    
    double[] coches = new double[10];
    
    private String color;
    private Double precio;
    
    public String avanzar(double gas, int mov){
        if(gas>mov){
            gas-=mov;
            return "El auto avanzo";
        }else{
            if(gas>1){
                while(gas>1){
                    gas-=1;
                }
                return "El auto avanzo";
            }else
            return "No hay suficiente combustible";
        }
    }
    
    public String avanzaDerecha(double gas, int mov){
        if(gas>mov){
            gas-=mov;
            return "El auto avanzo";
        }else{
            if(gas>1){
                while(gas>1){
                    gas-=1;
                }
                return "El auto pudo dar las vueltas a la derecha";
            }else
            return "No hay suficiente combustible";
        }
    }
    
    public String avanzaIzquierda(double gas, int mov){
        if(gas>mov){
            gas-=mov;
            return "El auto avanzo";
        }else{
            if(gas>1){
                while(gas>1){
                    gas-=1;
                }
                return "El auto pudo dar las vueltas a la derecha";
            }else
            return "No hay suficiente combustible";
        }
    }
}
