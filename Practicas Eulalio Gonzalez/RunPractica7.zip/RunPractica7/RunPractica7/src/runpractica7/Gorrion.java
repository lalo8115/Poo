/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica7;

/**
 *
 * @author eulalio
 */
public class Gorrion extends Animal{
    
    public String maullar(){
        return "Los gorrienes cantan";
    }

    @Override
    public String caminar(double caminar) {
        if(caminar>100){
            return "El gorrion "+ getNombre()+" voló más de 100 metros";
        }else{
           return "El gorrión "+getNombre()+" voló menos de 100 metros";
        }
    }


    

}
