/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runpractica7;

/**
 *
 * @author eulalio
 */
public class caballo extends Animal{
   

    @Override
    public String caminar(double caminar) {
        if(caminar>100){
            return "El caballo "+getNombre()+" caminó más de 100 metros";
        }else{
           return "El caballo "+getNombre()+" caminó de 100 metros";
        }
    }


}