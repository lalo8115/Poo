package Clases;
/**
 *
 * @author Eulalio Gonzalez Valencia
 */
public class Student extends Person{

    public Student(){
    
    }
    
    private String name_dir;
    
    public Student(String name, String address, String program, int year, double payment){
        this.name_dir = "Nombre: " + name + " Domicilio: " +  address ;
        this.program = program;
        this.year = year;
        this.payment = payment;
    }
    
    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getpayment() {
        return payment;
    }

    public void setpayment(double payment) {
        this.payment = payment;
    }
    
    private String program;
    private int year;
    private double payment;
    
    @Override
    public String toString(){
        return "Estudiante: " + name_dir + " Carrera: " + program + " Año: " + year + " Pago: " + payment;
    }
    
}
