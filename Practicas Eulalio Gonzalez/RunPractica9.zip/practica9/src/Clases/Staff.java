package Clases;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Eulalio Gonzalez Valencia
 */
public class Staff {

    private String name_dir;
    
    public Staff(String name, String address, String school, double salary){
        this.name_dir = "Nombre: " + name + " Domicilio: " +  address ;
        this.school = school;
        this.salary = salary;
    }
    
    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public double getsalary() {
        return salary;
    }

    public void setsalary(double salary) {
        this.salary = salary;
    }
    
    private String school;
    private double salary;
    
    @Override
    public String toString(){
        return "Staff: " + name_dir + " Escuela: " + school + " Paga: " + salary;
    }
    
}
